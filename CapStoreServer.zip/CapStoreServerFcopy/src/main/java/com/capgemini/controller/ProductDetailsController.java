package com.capgemini.controller;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.model.Product;
import com.capgemini.service.ProductDetailsService;

@RestController
public class ProductDetailsController {

	@Autowired
	ProductDetailsService service;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getProductDetails/{id}")
	public ArrayList<Product> getProductDetails(@PathVariable int id) {
		return service.getProductDetails(id);

	}
}
