package com.capgemini.service;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.model.Product;

public interface ProductDetailsService {

	public ArrayList getProductDetails(int id);
	
}
