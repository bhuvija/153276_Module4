package com.capgemini.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.model.Product;
import com.capgemini.repository.ProductDetails;

@Service("service")
public class ProductDetailsImpl implements ProductDetailsService {
	@Autowired(required = true)
	ProductDetails repo;

	@Override
	@Transactional
	public ArrayList<Product> getProductDetails(int id) {
		return repo.getProductDetails(id);

	}

}
